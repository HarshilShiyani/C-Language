#include<stdio.h>
void main()
{
 int a=10,*pa,**pb;
    pa=&a;
    printf("%d\n",a);
    printf("%d\n",pa);
    printf("%d\n",*pa);
    pb=&pa;
    printf("%d\n",pb);
    printf("%d\n",**pb);
    printf("%d\n",*pb);
}
