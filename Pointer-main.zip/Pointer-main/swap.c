#include<stdio.h>
void main()
{  
	int a,b,c;
	printf("Enter value of a=");
	scanf("%d",&a);
	printf("Enter value of b=");
	scanf("%d",&b);
	int *pa,*pb;
	pa=&a;
	pb=&b;
	c=*pa;
	*pa=*pb;
	*pb=c;
	printf("new value of a =%d\n",*pa);
	printf("new value of b=%d\n",*pb);	
}