#include<stdio.h>
void main()
{  
	int a,b;
	printf("Enter value of a");
	scanf("%d",&a);
	printf("Enter value of b");
	scanf("%d",&b);
	int *pa,*pb;
	pa=&a;
	pb=&b;


	printf("sum=%d",*pa+*pb);
	
}