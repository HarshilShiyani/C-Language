#include<stdio.h>
void main()
{  
	int a[4],*ptr,i,sum=0;
	ptr=a;
	for(i=0;i<4;i++)
	{
		scanf("%d",ptr+i);
	}
	for(i=0;i<4;i++)
	{
		sum=sum+*(ptr+i);
	}
	
	printf("Sum of Array Element=%d",sum);
}