#include<stdio.h>
void main()
{  
	int a=11;
	int *pa;
	pa=&a;


	printf("Address=%u\n",pa);
	printf("value=%u\n",*pa);
}