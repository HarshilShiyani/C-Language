#include<stdio.h>
void main()
{  
	int a[4],*ptr,i;
	ptr=a;
	for(i=0;i<4;i++)
	{
		scanf("%d",ptr+i);
	}
		for(i=0;i<4;i++)
	{
		printf("%d",*(ptr+i));
	}
	
	
}