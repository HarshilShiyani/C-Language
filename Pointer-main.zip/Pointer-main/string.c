#include<stdio.h>
#include<string.h>
void main()
{  
	char a[10],*ptr,i;
	ptr=a;
	scanf("%s",a);

	for (i=0;i<strlen(a);i++)
		{
			printf("%c is at location=%u\n",*(ptr+i),(ptr+i));
		}	
	
	
	
}