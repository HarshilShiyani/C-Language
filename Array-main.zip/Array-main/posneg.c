#include<stdio.h>
void main()

{ int i,neg=0,pos=0,zero=0,n;
   printf("Enter Array Index");
   scanf("%d",&n);

	int num[n];
	for(i=0;i<n+1;i++)
	{
		printf("Enter array=");
		scanf("%d",&num[i]);

    }
    for(i=0;i<n+1;i++)
    {   
    	if(num[i]>0)
       {
       	pos++;
       }
      if(num[i]<0)
       {
       	neg++;
       }
      if(num[i]==0)
       {
       	zero++;
       }	
    }	
    printf("Positive Number%d\n",pos);
    printf("Negative Number%d\n",neg);
    printf("Enter zero%d times\n",zero);
}