#include<stdio.h>
void main()

{ int i,n,sum=0,avg=0,max,min;
   printf("Enter Array Index");
   scanf("%d",&n);

	int num[n];
	for(i=0;i<n+1;i++)
	{
		printf("Enter array=");
		scanf("%d",&num[i]);

    }
    for(i=0;i<n+1;i++)
    {
       	sum=sum+num[i];

    }	
    avg=(sum/(n+1));
   printf("Total is%d\n",sum); 
   printf("Average is%d\n",avg); 
   max=num[0];
   for (i=0;i<n+1;i++)
   {
      if(num[i]>max)
      {
         max=num[i];
      }
   }
   printf("Maximum Number is=%d\n",max);
   min=num[0];
   for (i=0;i<n+1;i++)
   {
      if(num[i]<min)
      {
         min=num[i];
      }
   }
   printf("Minumum Number is=%d\n",min);
}