#include<stdio.h>
void main()

{ int i,even=0,odd=0,n;
   printf("Enter Array Index");
   scanf("%d",&n);

	int num[n];
	for(i=0;i<n+1;i++)
	{
		printf("Enter array=");
		scanf("%d",&num[i]);

    }
    for(i=0;i<n+1;i++)
    {   
    	if(num[i]%2==0)
       {
       	even++;
       }
      else
       {	
         odd++;

       }

       	
    }	
    printf("Even Number%d\n",even);
    printf("Odd Number%d\n",odd);
    
}