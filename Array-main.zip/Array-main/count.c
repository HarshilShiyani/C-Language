#include<stdio.h>
void main()

{ int i,n,sum=0,avg=0,count=0;
   printf("Enter Array Index");
   scanf("%d",&n);

	int num[n];
	for(i=0;i<n+1;i++)
	{
		printf("Enter array=");
		scanf("%d",&num[i]);

    }
    for(i=0;i<n+1;i++)
    {
       	sum=sum+num[i];

    }	
    avg=(sum/(n+1));
   for(i=0;i<n+1;i++)
   {
      if(num[i]>avg)
          {
            count++; 
         }
   }
   printf("count is%d",count);
}