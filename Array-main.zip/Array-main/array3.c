#include<stdio.h>
void main()

{ int i,j;
   

	int num[2][2];
  
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
    {
      printf("Enter=");
      scanf("%d",&num[i][j]);

    }

  }
  for(i=0;i<3;i++)
  {
    for(j=0;j<3;j++)
    {
      printf("%d",num[i][j]);
      




    }
      printf("\n");
  }
}