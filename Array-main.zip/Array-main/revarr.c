#include<stdio.h>
void main()

{ 
	int num[10],i;
	for(i=0;i<10;i++)
	{
		printf("Enter array=");
		scanf("%d",&num[i]);

    }
    for(i=9;i>=0;i--)
    {
       printf("ans=%d\n",num[i]);
    }	
}